CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- 实际生产中应存储哈希值，这里为演示存明文
    phone_number VARCHAR(20) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL,
    security_question VARCHAR(255) NOT NULL,
    security_answer VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 航班表 (用于显示订单中的航班信息)
CREATE TABLE IF NOT EXISTS flights (
    flight_id VARCHAR(20) PRIMARY KEY, -- 例如 CA1831
    airline VARCHAR(50),
    departure_city VARCHAR(50),
    arrival_city VARCHAR(50),
    departure_airport VARCHAR(100),
    arrival_airport VARCHAR(100),
    departure_time DATETIME,
    arrival_time DATETIME,
    price_economy DECIMAL(10, 2),
    price_first_class DECIMAL(10, 2),
    seats_economy_total INT,
    seats_economy_sold INT DEFAULT 0,
    seats_first_total INT,
    seats_first_sold INT DEFAULT 0
);

-- 订单表
CREATE TABLE IF NOT EXISTS orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    flight_id VARCHAR(20) NOT NULL,
    passenger_name VARCHAR(50),
    passenger_id_card VARCHAR(30),
    passenger_phone VARCHAR(20),
    seat_type VARCHAR(20), -- 'economy' or 'first_class'
    status VARCHAR(20) DEFAULT 'pending_payment', -- pending_payment, confirmed, canceled
    total_price DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    paid_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (flight_id) REFERENCES flights(flight_id)
);

-- 为了方便测试 '获取订单列表' 接口，我们可以手动插入一条测试航班和订单
-- (如果不插数据，接口返回空列表也是正常的)
INSERT IGNORE INTO flights (flight_id, airline, departure_city, arrival_city, departure_time, price_economy) 
VALUES ('TEST001', '测试航空', '北京', '上海', '2025-11-13 08:00:00', 500.00);

-- 插入更多航班数据用于搜索测试
INSERT IGNORE INTO flights (flight_id, airline, departure_city, arrival_city, departure_airport, arrival_airport, departure_time, arrival_time, price_economy, price_first_class, seats_economy_total, seats_first_total) VALUES 
('CA1001', '中国国际航空', '北京', '上海', '北京首都T3', '上海虹桥T2', '2025-11-15 08:00:00', '2025-11-15 10:30:00', 800.00, 2400.00, 100, 10),
('MU5183', '东方航空', '北京', '上海', '北京大兴', '上海浦东T1', '2025-11-15 09:00:00', '2025-11-15 11:30:00', 750.00, 2200.00, 100, 10),
('CZ3001', '南方航空', '北京', '广州', '北京大兴', '广州白云T2', '2025-11-15 14:00:00', '2025-11-15 17:30:00', 1200.00, 3500.00, 150, 20),
('HU7788', '海南航空', '上海', '深圳', '上海虹桥T2', '深圳宝安T3', '2025-11-16 10:00:00', '2025-11-16 12:45:00', 900.00, 2800.00, 120, 10);