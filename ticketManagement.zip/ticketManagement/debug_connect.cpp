#include <mysql/mysql.h>
#include <iostream>

int main() {
    std::cout << "Starting diagnostic..." << std::endl;
    
    // 1. 打印客户端版本 (看看你用的 libmariadb 到底是多少版本的)
    std::cout << "Client Version: " << mysql_get_client_info() << std::endl;

    MYSQL* conn = mysql_init(nullptr);
    if (!conn) {
        std::cerr << "mysql_init failed!" << std::endl;
        return 1;
    }

    // 2. 强制加载插件目录 (试图修复找不到插件的问题)
    // 请确保 build/lib/plugin 存在
    mysql_options(conn, MYSQL_PLUGIN_DIR, "lib/plugin");

    // 3. 尝试连接
    // 注意：把 IP, User, Pass 改成你的
    if (!mysql_real_connect(conn, "127.0.0.1", "admin", "123456", "flight_booking_system", 3306, nullptr, 0)) {
        // 4. 打印详细的错误码 (Error Number)
        // Error 1045 = 密码错误
        // Error 2059 = 插件无法加载
        // Error 2026 = SSL 错误
        std::cerr << "Code: " << mysql_errno(conn) << std::endl;
        std::cerr << "Msg : " << mysql_error(conn) << std::endl;
    } else {
        std::cout << "SUCCESS! Connection established!" << std::endl;
        mysql_close(conn);
    }

    return 0;
}