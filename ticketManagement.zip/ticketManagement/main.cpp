// ==========================================
// main.cpp - API 1 & 2: Login & Profile
// ==========================================
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#ifdef __MINGW32__
extern "C" {
    INT WSAAPI GetAddrInfoExCancel(LPHANDLE lpHandle);
}
#endif
#endif

#include <httplib.h>
#include <nlohmann/json.hpp>
#include "DBPool.hpp"
#include <string>
#include <iostream>
#include <map>
#include <random>
#include <sstream>
#include <mutex>

using json = nlohmann::json;
using namespace std;

// ==========================================
// Token 管理器
// ==========================================
class TokenManager {
private:
    std::map<std::string, int> token_map; // Token -> UserID
    std::mutex mtx;

    std::string generate_token_string() {
        static const char alphanum[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        std::string tmp_s;
        tmp_s.reserve(32);
        static std::mt19937 rg{std::random_device{}()};
        static std::uniform_int_distribution<std::string::size_type> pick(0, sizeof(alphanum) - 2);
        for (int i = 0; i < 32; ++i) tmp_s += alphanum[pick(rg)];
        return tmp_s;
    }

public:
    static TokenManager& GetInstance() {
        static TokenManager instance;
        return instance;
    }

    std::string CreateToken(int user_id) {
        std::lock_guard<std::mutex> lock(mtx);
        std::string token = generate_token_string();
        token_map[token] = user_id;
        return token;
    }

    int ValidateToken(const std::string& token) {
        std::lock_guard<std::mutex> lock(mtx);
        auto it = token_map.find(token);
        return (it != token_map.end()) ? it->second : -1;
    }
    
    void RemoveToken(const std::string& token) {
        std::lock_guard<std::mutex> lock(mtx);
        token_map.erase(token);
    }
};

// ==========================================
// 辅助函数
// ==========================================
void send_json_response(httplib::Response& res, int code, const std::string& status, const std::string& message, const json& data = nullptr) {
    json response;
    response["status"] = status;
    response["code"] = code;
    response["message"] = message;
    response["data"] = data;
    res.status = code;
    res.set_content(response.dump(), "application/json");
}

std::string sql_escape(MYSQL* conn, const std::string& str) {
    if (str.empty()) return "";
    char* escaped = new char[str.length() * 2 + 1];
    mysql_real_escape_string(conn, escaped, str.c_str(), str.length());
    std::string res(escaped);
    delete[] escaped;
    return res;
}

// 提取 Token 并验证，返回 user_id，失败返回 -1
int auth_check(const httplib::Request& req) {
    if (!req.has_header("Authorization")) return -1;
    string auth = req.get_header_value("Authorization");
    if (auth.find("Bearer ") != 0) return -1;
    string token = auth.substr(7);
    return TokenManager::GetInstance().ValidateToken(token);
}

// ==========================================
// 主程序
// ==========================================
int main() {
    DBConfig dbConf;
    dbConf.user = "root";
    dbConf.pass = "123456"; // 修改为你的密码
    dbConf.db_name = "flight_booking_system";
    
    DBPool::GetInstance().Init(dbConf, 5);
    std::cout << "Database pool initialized." << std::endl;

    httplib::Server svr;

    // ---------------------------------------------------------
    // API 1: 注册与登录
    // ---------------------------------------------------------

    // 3.1 用户注册
    svr.Post("/api/users", [](const httplib::Request& req, httplib::Response& res) {
        json body;
        try { body = json::parse(req.body); } catch (...) { return send_json_response(res, 400, "error", "Invalid JSON format"); }

        DBGuard db;
        MYSQL* conn = db.Get();

        string username = sql_escape(conn, body.value("username", ""));
        string password = sql_escape(conn, body.value("password", ""));
        string phone = sql_escape(conn, body.value("phone_number", ""));
        string email = sql_escape(conn, body.value("email", ""));
        string sq = sql_escape(conn, body.value("security_question", ""));
        string sa = sql_escape(conn, body.value("security_answer", ""));

        if(username.empty() || password.empty()) return send_json_response(res, 400, "error", "Missing fields");

        string sql = "INSERT INTO users (username, password, phone_number, email, security_question, security_answer) VALUES ('"
                     + username + "', '" + password + "', '" + phone + "', '" + email + "', '" + sq + "', '" + sa + "')";
        
        if (mysql_query(conn, sql.c_str())) {
            // 简单判断 Error 1062 Duplicate entry
            if (mysql_errno(conn) == 1062) return send_json_response(res, 409, "error", "用户名或手机号已存在");
            return send_json_response(res, 500, "error", "Database error");
        }

        json data;
        data["user_id"] = mysql_insert_id(conn);
        data["username"] = body["username"];
        send_json_response(res, 201, "success", "注册成功", data);
    });

    // 3.2 用户登录
    svr.Post("/api/auth/login", [](const httplib::Request& req, httplib::Response& res) {
        json body;
        try { body = json::parse(req.body); } catch (...) { return send_json_response(res, 400, "error", "Invalid JSON"); }

        string ident = body.value("identifier", "");
        string pass = body.value("password", "");

        DBGuard db;
        MYSQL* conn = db.Get();
        string ident_esc = sql_escape(conn, ident);
        string pass_esc = sql_escape(conn, pass);

        string sql = "SELECT user_id, username FROM users WHERE (username='" + ident_esc + "' OR phone_number='" + ident_esc + "') AND password='" + pass_esc + "'";
        if (mysql_query(conn, sql.c_str())) return send_json_response(res, 500, "error", "Database error");

        MYSQL_RES* result = mysql_store_result(conn);
        if (result && mysql_num_rows(result) > 0) {
            MYSQL_ROW row = mysql_fetch_row(result);
            int uid = stoi(row[0]);
            string u_name = row[1];
            mysql_free_result(result);

            string token = TokenManager::GetInstance().CreateToken(uid);
            json data = {{"token", token}, {"user_id", uid}, {"username", u_name}};
            send_json_response(res, 200, "success", "登录成功", data);
        } else {
            if(result) mysql_free_result(result);
            send_json_response(res, 401, "error", "用户名或密码错误");
        }
    });

    // 3.3 修改密码
    svr.Put("/api/users/password", [](const httplib::Request& req, httplib::Response& res) {
        int user_id = auth_check(req);
        if (user_id == -1) return send_json_response(res, 401, "error", "用户未登录或会话已过期");

        json body;
        try { body = json::parse(req.body); } catch (...) { return send_json_response(res, 400, "error", "Invalid JSON"); }

        string old_pass = body.value("old_password", "");
        string new_pass = body.value("new_password", "");
        string confirm_pass = body.value("confirm_password", "");

        if (new_pass != confirm_pass) return send_json_response(res, 400, "error", "两次输入的新密码不一致");

        DBGuard db;
        MYSQL* conn = db.Get();
        string old_esc = sql_escape(conn, old_pass);
        string new_esc = sql_escape(conn, new_pass);

        // 校验旧密码 + 更新新密码
        string sql = "UPDATE users SET password='" + new_esc + "' WHERE user_id=" + to_string(user_id) + " AND password='" + old_esc + "'";
        if (mysql_query(conn, sql.c_str())) return send_json_response(res, 500, "error", "Database error");

        if (mysql_affected_rows(conn) > 0) {
            send_json_response(res, 200, "success", "密码修改成功");
        } else {
            send_json_response(res, 400, "error", "旧密码不正确");
        }
    });

    // 3.4 获取安全问题
    svr.Get(R"(/api/users/([^/]+)/security-question)", [](const httplib::Request& req, httplib::Response& res) {
        string username = req.matches[1];
        DBGuard db;
        MYSQL* conn = db.Get();
        string user_esc = sql_escape(conn, username);

        string sql = "SELECT security_question FROM users WHERE username='" + user_esc + "'";
        if (mysql_query(conn, sql.c_str())) return send_json_response(res, 500, "error", "DB Error");
        
        MYSQL_RES* result = mysql_store_result(conn);
        if (result && mysql_num_rows(result) > 0) {
            MYSQL_ROW row = mysql_fetch_row(result);
            json data; data["question"] = row[0];
            mysql_free_result(result);
            send_json_response(res, 200, "success", "获取成功", data);
        } else {
            if(result) mysql_free_result(result);
            send_json_response(res, 404, "error", "用户不存在");
        }
    });

    // 3.5 重置密码
    svr.Post("/api/auth/reset-password", [](const httplib::Request& req, httplib::Response& res) {
        json body; 
        try { body = json::parse(req.body); } catch (...) { return send_json_response(res, 400, "error", "Invalid JSON"); }

        string new_p = body.value("new_password", "");
        if (new_p != body.value("confirm_password", "")) return send_json_response(res, 400, "error", "密码不一致");

        DBGuard db;
        MYSQL* conn = db.Get();
        string u = sql_escape(conn, body.value("username", ""));
        string a = sql_escape(conn, body.value("security_answer", ""));
        string p = sql_escape(conn, new_p);

        string sql = "UPDATE users SET password='" + p + "' WHERE username='" + u + "' AND security_answer='" + a + "'";
        if (mysql_query(conn, sql.c_str())) return send_json_response(res, 500, "error", "DB Error");

        if (mysql_affected_rows(conn) > 0) send_json_response(res, 200, "success", "密码重置成功");
        else send_json_response(res, 400, "error", "用户名或答案错误");
    });

    // ---------------------------------------------------------
    // API 2: 个人中心
    // ---------------------------------------------------------

    // 5.1 获取用户信息
    svr.Get("/api/users/profile", [](const httplib::Request& req, httplib::Response& res) {
        int user_id = auth_check(req);
        if (user_id == -1) return send_json_response(res, 401, "error", "用户未登录或会话已过期");

        DBGuard db;
        MYSQL* conn = db.Get();
        
        string sql = "SELECT user_id, username, phone_number, email, security_question FROM users WHERE user_id=" + to_string(user_id);
        if (mysql_query(conn, sql.c_str())) return send_json_response(res, 500, "error", "DB Error");

        MYSQL_RES* result = mysql_store_result(conn);
        if (result && mysql_num_rows(result) > 0) {
            MYSQL_ROW row = mysql_fetch_row(result);
            json data;
            data["user_id"] = stoi(row[0]);
            data["username"] = row[1];
            data["phone_number"] = row[2];
            data["email"] = row[3];
            data["security_question"] = row[4];
            mysql_free_result(result);
            send_json_response(res, 200, "success", "获取用户信息成功", data);
        } else {
            if(result) mysql_free_result(result);
            send_json_response(res, 404, "error", "用户不存在");
        }
    });

    // 5.2 获取我的订单列表 (包含分页和联表查询)
    svr.Get("/api/users/orders", [](const httplib::Request& req, httplib::Response& res) {
        int user_id = auth_check(req);
        if (user_id == -1) return send_json_response(res, 401, "error", "用户未登录");

        // 处理分页参数
        int page = 1;
        int page_size = 10;
        if (req.has_param("page")) page = stoi(req.get_param_value("page"));
        if (req.has_param("page_size")) page_size = stoi(req.get_param_value("page_size"));
        if (page < 1) page = 1;
        if (page_size < 1) page_size = 10;
        int offset = (page - 1) * page_size;

        DBGuard db;
        MYSQL* conn = db.Get();

        // 1. 查询总数
        string countSql = "SELECT COUNT(*) FROM orders WHERE user_id=" + to_string(user_id);
        if (mysql_query(conn, countSql.c_str())) return send_json_response(res, 500, "error", "DB Error");
        
        MYSQL_RES* resCount = mysql_store_result(conn);
        int total_items = 0;
        if (resCount && mysql_num_rows(resCount) > 0) {
            MYSQL_ROW row = mysql_fetch_row(resCount);
            total_items = stoi(row[0]);
            mysql_free_result(resCount);
        }

        // 2. 查询列表 (联表: orders + flights)
        // 目标字段: order_id, flight_id, departure_city, arrival_city, departure_time, status, total_price
        stringstream ss;
        ss << "SELECT o.order_id, o.flight_id, f.departure_city, f.arrival_city, f.departure_time, o.status, o.total_price "
           << "FROM orders o "
           << "JOIN flights f ON o.flight_id = f.flight_id "
           << "WHERE o.user_id=" << user_id << " "
           << "ORDER BY o.created_at DESC "
           << "LIMIT " << offset << ", " << page_size;

        if (mysql_query(conn, ss.str().c_str())) return send_json_response(res, 500, "error", "DB Error: " + string(mysql_error(conn)));

        MYSQL_RES* result = mysql_store_result(conn);
        json list = json::array();
        if (result) {
            MYSQL_ROW row;
            while ((row = mysql_fetch_row(result))) {
                json item;
                item["order_id"] = stoi(row[0]);
                item["flight_id"] = row[1];
                item["departure_city"] = row[2];
                item["arrival_city"] = row[3];
                item["departure_time"] = row[4]; // datetime string
                item["status"] = row[5];
                item["total_price"] = row[6] ? stod(row[6]) : 0.0;
                list.push_back(item);
            }
            mysql_free_result(result);
        }

        json data;
        data["total_items"] = total_items;
        data["total_pages"] = (total_items + page_size - 1) / page_size;
        data["current_page"] = page;
        data["page_size"] = page_size;
        data["list"] = list;

        string msg = (total_items == 0) ? "查询成功，未找到订单" : "查询成功";
        send_json_response(res, 200, "success", msg, data);
    });

    // 5.3 修改用户名
    svr.Put("/api/users/username", [](const httplib::Request& req, httplib::Response& res) {
        int user_id = auth_check(req);
        if (user_id == -1) return send_json_response(res, 401, "error", "用户未登录");

        json body;
        try { body = json::parse(req.body); } catch (...) { return send_json_response(res, 400, "error", "Invalid JSON"); }
        string new_name = body.value("new_username", "");
        if (new_name.empty()) return send_json_response(res, 400, "error", "用户名不能为空");

        DBGuard db;
        MYSQL* conn = db.Get();
        string name_esc = sql_escape(conn, new_name);

        string sql = "UPDATE users SET username='" + name_esc + "' WHERE user_id=" + to_string(user_id);
        if (mysql_query(conn, sql.c_str())) {
            if (mysql_errno(conn) == 1062) return send_json_response(res, 409, "error", "用户名 '" + new_name + "' 已被占用");
            return send_json_response(res, 500, "error", "DB Error");
        }

        json data; data["new_username"] = new_name;
        send_json_response(res, 200, "success", "用户名修改成功", data);
    });

    // 5.4 退出登录
    svr.Post("/api/auth/logout", [](const httplib::Request& req, httplib::Response& res) {
        // 虽然登出通常只需要有 Token 即可，但我们还是通过 auth_check 验证一下有效性
        // 或者直接从 Header 获取然后移除
        if (!req.has_header("Authorization")) return send_json_response(res, 401, "error", "Token missing");
        string auth = req.get_header_value("Authorization");
        string token = auth.substr(7);

        TokenManager::GetInstance().RemoveToken(token);
        send_json_response(res, 200, "success", "退出登录成功");
    });

    // ==========================================
    // API 3: 航班与订单系统 (新增代码)
    // ==========================================

    // 4.1 搜索航班
    // GET /api/flights
    svr.Get("/api/flights", [](const httplib::Request& req, httplib::Response& res) {
        // 1. 获取参数
        string dep_city = req.get_param_value("departure_city");
        string arr_city = req.get_param_value("arrival_city");
        string dep_date = req.get_param_value("departure_date"); // "YYYY-MM-DD"
        
        // 必填项校验
        if (dep_city.empty() || arr_city.empty() || dep_date.empty()) {
            return send_json_response(res, 400, "error", "缺少必填参数: departure_city, arrival_city, departure_date");
        }

        DBGuard db;
        MYSQL* conn = db.Get();
        
        // 2. 动态拼接 SQL
        stringstream sql;
        sql << "SELECT flight_id, airline, departure_city, arrival_city, departure_airport, arrival_airport, "
            << "departure_time, arrival_time, price_economy, price_first_class, "
            << "(seats_economy_total - seats_economy_sold) as avail_eco, "
            << "(seats_first_total - seats_first_sold) as avail_first "
            << "FROM flights WHERE 1=1 ";
        
        sql << "AND departure_city='" << sql_escape(conn, dep_city) << "' ";
        sql << "AND arrival_city='" << sql_escape(conn, arr_city) << "' ";
        // 日期匹配: 使用 DATE() 函数截取数据库中的 DATETIME
        sql << "AND DATE(departure_time)='" << sql_escape(conn, dep_date) << "' ";

        // 可选筛选
        if (req.has_param("airline")) 
            sql << "AND airline LIKE '%" << sql_escape(conn, req.get_param_value("airline")) << "%' ";
        if (req.has_param("price_max")) 
            sql << "AND price_economy <= " << req.get_param_value("price_max") << " ";

        // 分页
        int page = req.has_param("page") ? stoi(req.get_param_value("page")) : 1;
        int size = req.has_param("page_size") ? stoi(req.get_param_value("page_size")) : 10;
        int offset = (page < 1 ? 0 : page - 1) * size;
        
        // 我们可以先查总数 (略，为节省代码直接查列表)
        sql << "ORDER BY departure_time ASC LIMIT " << offset << "," << size;

        if (mysql_query(conn, sql.str().c_str())) return send_json_response(res, 500, "error", "DB Error");

        MYSQL_RES* result = mysql_store_result(conn);
        json list = json::array();
        int count = 0;
        if (result) {
            MYSQL_ROW row;
            while ((row = mysql_fetch_row(result))) {
                json f;
                f["flight_id"] = row[0];
                f["airline"] = row[1];
                f["departure_city"] = row[2];
                f["arrival_city"] = row[3];
                f["departure_airport"] = row[4];
                f["arrival_airport"] = row[5];
                f["departure_time"] = row[6];
                f["arrival_time"] = row[7];
                f["seat_prices"] = { {"economy", stod(row[8])}, {"first_class", stod(row[9])} };
                f["available_seats"] = { {"economy", stoi(row[10])}, {"first_class", stoi(row[11])} };
                list.push_back(f);
                count++;
            }
            mysql_free_result(result);
        }

        json data;
        data["list"] = list;
        data["total_items"] = count; // 简化处理，仅返回当前页数量
        data["current_page"] = page;
        
        string msg = (count == 0) ? "查询成功，未找到符合条件的航班" : "查询成功";
        send_json_response(res, 200, "success", msg, data);
    });

    // 4.2 创建订单
    // POST /api/orders
    svr.Post("/api/orders", [](const httplib::Request& req, httplib::Response& res) {
        int user_id = auth_check(req);
        if (user_id == -1) return send_json_response(res, 401, "error", "未授权");

        json body;
        try { body = json::parse(req.body); } catch (...) { return send_json_response(res, 400, "error", "Invalid JSON"); }

        string flight_id = body.value("flight_id", "");
        string seat_type = body.value("seat_type", ""); // "economy" or "first_class"
        
        if (flight_id.empty() || (seat_type != "economy" && seat_type != "first_class")) 
            return send_json_response(res, 400, "error", "参数错误：航班ID或舱位类型无效");

        json pass_obj = body["passenger"];
        string p_name = pass_obj.value("name", "");
        string p_id = pass_obj.value("id_card", "");
        string p_phone = pass_obj.value("phone", "");

        DBGuard db;
        MYSQL* conn = db.Get();
        string fid_esc = sql_escape(conn, flight_id);
        string type_esc = sql_escape(conn, seat_type);
        string pname_esc = sql_escape(conn, p_name);
        string pid_esc = sql_escape(conn, p_id);
        string pphone_esc = sql_escape(conn, p_phone);

        // --- 开启事务 ---
        mysql_query(conn, "START TRANSACTION");

        // 1. 尝试扣减库存 (乐观锁: 只有库存足够才更新成功)
        string col_sold = (seat_type == "economy") ? "seats_economy_sold" : "seats_first_sold";
        string col_total = (seat_type == "economy") ? "seats_economy_total" : "seats_first_total";
        
        string updateSql = "UPDATE flights SET " + col_sold + " = " + col_sold + " + 1 "
                         + "WHERE flight_id='" + fid_esc + "' AND " + col_sold + " < " + col_total;

        if (mysql_query(conn, updateSql.c_str())) {
            mysql_query(conn, "ROLLBACK");
            return send_json_response(res, 500, "error", "DB Error Update");
        }

        if (mysql_affected_rows(conn) == 0) {
            mysql_query(conn, "ROLLBACK");
            return send_json_response(res, 400, "error", "创建订单失败，该舱位已售罄");
        }

        // 2. 获取票价
        string priceCol = (seat_type == "economy") ? "price_economy" : "price_first_class";
        string queryPrice = "SELECT " + priceCol + " FROM flights WHERE flight_id='" + fid_esc + "'";
        mysql_query(conn, queryPrice.c_str());
        MYSQL_RES* resPrice = mysql_store_result(conn);
        double price = 0.0;
        if (resPrice) {
            MYSQL_ROW row = mysql_fetch_row(resPrice);
            if(row) price = stod(row[0]);
            mysql_free_result(resPrice);
        }

        // 3. 插入订单
        stringstream ss;
        ss << "INSERT INTO orders (user_id, flight_id, passenger_name, passenger_id_card, passenger_phone, seat_type, status, total_price) VALUES ("
           << user_id << ", '" << fid_esc << "', '" << pname_esc << "', '" << pid_esc << "', '" << pphone_esc << "', '" 
           << type_esc << "', 'pending_payment', " << price << ")";
        
        if (mysql_query(conn, ss.str().c_str())) {
            mysql_query(conn, "ROLLBACK");
            return send_json_response(res, 500, "error", "DB Error Insert");
        }

        int order_id = mysql_insert_id(conn);

        // --- 提交事务 ---
        mysql_query(conn, "COMMIT");

        json data;
        data["order_id"] = order_id;
        data["status"] = "pending_payment";
        data["total_price"] = price;
        // 简单计算过期时间 (当前时间+15分钟，这里仅返回字符串示意，实际可用库计算)
        data["expires_at"] = "15分钟后"; 
        
        send_json_response(res, 201, "success", "订单创建成功，请在15分钟内支付", data);
    });

    // 4.3 支付订单
    // POST /api/orders/{id}/payment
    svr.Post(R"(/api/orders/(\d+)/payment)", [](const httplib::Request& req, httplib::Response& res) {
        int user_id = auth_check(req);
        if (user_id == -1) return send_json_response(res, 401, "error", "未授权");
        
        int order_id = stoi(req.matches[1]);
        DBGuard db;
        MYSQL* conn = db.Get();

        // 检查订单: 必须属于该用户，状态为 pending，且未超时 (15分钟 = 900秒)
        // TIMESTAMPDIFF(SECOND, created_at, NOW())
        stringstream checkSql;
        checkSql << "SELECT order_id, TIMESTAMPDIFF(SECOND, created_at, NOW()) as diff FROM orders "
                 << "WHERE order_id=" << order_id << " AND user_id=" << user_id << " AND status='pending_payment'";
        
        if (mysql_query(conn, checkSql.str().c_str())) return send_json_response(res, 500, "error", "DB Error");
        
        MYSQL_RES* result = mysql_store_result(conn);
        if (!result || mysql_num_rows(result) == 0) {
            if(result) mysql_free_result(result);
            return send_json_response(res, 404, "error", "订单不存在、已支付或不属于您");
        }

        MYSQL_ROW row = mysql_fetch_row(result);
        int seconds_passed = row[1] ? stoi(row[1]) : 0;
        mysql_free_result(result);

        if (seconds_passed > 900) { // 15分钟超时
            // 自动标记为过期 (逻辑上还可以把库存加回去，这里简化处理只改状态)
            // 严谨做法：开启事务 -> 改状态 -> 恢复库存 -> 提交
            mysql_query(conn, ("UPDATE orders SET status='expired' WHERE order_id=" + to_string(order_id)).c_str());
            return send_json_response(res, 400, "error", "订单已超时关闭");
        }

        // 执行支付
        string paySql = "UPDATE orders SET status='confirmed', paid_at=NOW() WHERE order_id=" + to_string(order_id);
        if (mysql_query(conn, paySql.c_str())) return send_json_response(res, 500, "error", "DB Error Update");

        json data;
        data["order_id"] = order_id;
        data["status"] = "confirmed";
        send_json_response(res, 200, "success", "支付成功", data);
    });

    // 4.5 获取订单详情
    // GET /api/orders/{id}
    svr.Get(R"(/api/orders/(\d+))", [](const httplib::Request& req, httplib::Response& res) {
        int user_id = auth_check(req);
        if (user_id == -1) return send_json_response(res, 401, "error", "未授权");
        int order_id = stoi(req.matches[1]);

        DBGuard db;
        MYSQL* conn = db.Get();

        // 联表查询
        stringstream sql;
        sql << "SELECT o.order_id, o.status, o.total_price, o.created_at, o.seat_type, "
            << "f.flight_id, f.airline, f.departure_city, f.arrival_city, f.departure_time, f.arrival_time, "
            << "o.passenger_name, o.passenger_id_card, o.passenger_phone "
            << "FROM orders o JOIN flights f ON o.flight_id = f.flight_id "
            << "WHERE o.order_id=" << order_id << " AND o.user_id=" << user_id;

        if (mysql_query(conn, sql.str().c_str())) return send_json_response(res, 500, "error", "DB Error");

        MYSQL_RES* result = mysql_store_result(conn);
        if (result && mysql_num_rows(result) > 0) {
            MYSQL_ROW row = mysql_fetch_row(result);
            json data;
            data["order_id"] = stoi(row[0]);
            data["status"] = row[1];
            data["total_price"] = stod(row[2]);
            data["created_at"] = row[3];
            data["seat_type"] = row[4];
            
            data["flight_info"] = {
                {"flight_id", row[5]},
                {"airline", row[6]},
                {"departure_city", row[7]},
                {"arrival_city", row[8]},
                {"departure_time", row[9]},
                {"arrival_time", row[10]}
            };
            data["passenger_info"] = {
                {"name", row[11]},
                {"id_card", row[12]},
                {"phone", row[13]}
            };
            
            mysql_free_result(result);
            send_json_response(res, 200, "success", "查询成功", data);
        } else {
            if(result) mysql_free_result(result);
            send_json_response(res, 404, "error", "订单不存在");
        }
    });

    // 4.6 取消订单
    // DELETE /api/orders/{id}
    svr.Delete(R"(/api/orders/(\d+))", [](const httplib::Request& req, httplib::Response& res) {
        int user_id = auth_check(req);
        if (user_id == -1) return send_json_response(res, 401, "error", "未授权");
        int order_id = stoi(req.matches[1]);

        DBGuard db;
        MYSQL* conn = db.Get();

        // 1. 查询订单信息 (状态、航班ID、座位类型)
        stringstream q;
        q << "SELECT status, flight_id, seat_type FROM orders WHERE order_id=" << order_id << " AND user_id=" << user_id;
        if (mysql_query(conn, q.str().c_str())) return send_json_response(res, 500, "error", "DB Error");
        
        MYSQL_RES* result = mysql_store_result(conn);
        if (!result || mysql_num_rows(result) == 0) {
            if(result) mysql_free_result(result);
            return send_json_response(res, 404, "error", "订单不存在");
        }
        MYSQL_ROW row = mysql_fetch_row(result);
        string status = row[0];
        string flight_id = row[1];
        string seat_type = row[2];
        mysql_free_result(result);

        if (status == "canceled") return send_json_response(res, 400, "error", "订单已是取消状态");
        // 如果已过期，通常不认为是“取消成功”，而是“已过期”。但为了释放库存逻辑，这里假设未过期的才能取消。
        
        // --- 开启事务 ---
        mysql_query(conn, "START TRANSACTION");

        // 2. 更新订单状态
        string upOrder = "UPDATE orders SET status='canceled' WHERE order_id=" + to_string(order_id);
        if (mysql_query(conn, upOrder.c_str())) {
            mysql_query(conn, "ROLLBACK");
            return send_json_response(res, 500, "error", "DB Error");
        }

        // 3. 恢复库存
        string col = (seat_type == "economy") ? "seats_economy_sold" : "seats_first_sold";
        string upFlight = "UPDATE flights SET " + col + " = " + col + " - 1 WHERE flight_id='" + flight_id + "'";
        if (mysql_query(conn, upFlight.c_str())) {
            mysql_query(conn, "ROLLBACK");
            return send_json_response(res, 500, "error", "DB Error Stock");
        }

        // --- 提交事务 ---
        mysql_query(conn, "COMMIT");

        json data;
        data["order_id"] = order_id;
        data["status"] = "canceled";
        send_json_response(res, 200, "success", "订单已取消", data);
    });
    // ---------------------------------------------------------
    // 启动服务器
    std::cout << "Server listening on http://localhost:8080" << std::endl;
    svr.listen("0.0.0.0", 8080);

    return 0;
}