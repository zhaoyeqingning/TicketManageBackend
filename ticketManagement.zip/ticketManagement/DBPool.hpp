#ifndef DBPOOL_HPP
#define DBPOOL_HPP

#include <mysql.h>
#include <string>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <iostream>

struct DBConfig {
    // 1. 本地地址
    std::string host = "127.0.0.1"; // 或者 "localhost"
    
    // 2. 默认端口
    int port = 3306;
    
    // 3. 本地账号 (通常是 root)
    std::string user = "root";
    
    // 4. 本地密码 (你登录 Workbench 用的那个)
    std::string pass = "123456"; 
    
    // 5. 刚才创建的库名
    std::string db_name = "flight_booking_system";
};

class DBPool {
public:
    // 获取单例实例
    static DBPool& GetInstance() {
        static DBPool instance;
        return instance;
    }

    // 初始化连接池
    void Init(const DBConfig& config, int poolSize = 5) {
        
        config_ = config;
        for (int i = 0; i < poolSize; ++i) {
            MYSQL* conn = mysql_init(nullptr);

            // ====================================================
            // [新增] 关键配置：关闭 SSL 证书验证 + 开启断线重连
            // ====================================================
            bool reconnect = true;
            mysql_options(conn, MYSQL_OPT_RECONNECT, &reconnect);
            
            // 告诉客户端不要去校验服务器的证书是否合法
            bool verify_cert = false; 
            mysql_options(conn, MYSQL_OPT_SSL_VERIFY_SERVER_CERT, &verify_cert);
            // ====================================================
            mysql_options(conn, MYSQL_PLUGIN_DIR, "lib/plugin");
            if (!mysql_real_connect(conn, config.host.c_str(), config.user.c_str(), 
                                    config.pass.c_str(), config.db_name.c_str(), 
                                    config.port, nullptr, 0)) {
                std::cerr << "MySQL connection failed: " << mysql_error(conn) << std::endl;
                mysql_close(conn);
            } else {
                connections_.push(conn);
            }
        }
    }

    // 获取一个连接
    MYSQL* GetConnection() {
        std::unique_lock<std::mutex> lock(mutex_);
        // 如果池空了，就等待
        while (connections_.empty()) {
            condition_.wait(lock);
        }
        MYSQL* conn = connections_.front();
        connections_.pop();
        
        // 简单检查连接是否还活着，死了重连
        if (mysql_ping(conn) != 0) {
            std::cout << "Reconnecting..." << std::endl;
            mysql_close(conn);
            conn = mysql_init(nullptr);
            mysql_real_connect(conn, config_.host.c_str(), config_.user.c_str(), 
                               config_.pass.c_str(), config_.db_name.c_str(), 
                               config_.port, nullptr, 0);
        }
        
        return conn;
    }

    // 归还连接
    void ReturnConnection(MYSQL* conn) {
        std::unique_lock<std::mutex> lock(mutex_);
        connections_.push(conn);
        condition_.notify_one();
    }

    // 析构释放
    ~DBPool() {
        while (!connections_.empty()) {
            MYSQL* conn = connections_.front();
            connections_.pop();
            mysql_close(conn);
        }
    }

private:
    DBPool() = default;
    DBPool(const DBPool&) = delete;
    DBPool& operator=(const DBPool&) = delete;

    std::queue<MYSQL*> connections_;
    std::mutex mutex_;
    std::condition_variable condition_;
    DBConfig config_;
};

// 辅助类：自动归还连接 (RAII)
class DBGuard {
public:
    DBGuard() {
        conn_ = DBPool::GetInstance().GetConnection();
    }
    ~DBGuard() {
        DBPool::GetInstance().ReturnConnection(conn_);
    }
    MYSQL* Get() { return conn_; }
private:
    MYSQL* conn_;
};

#endif